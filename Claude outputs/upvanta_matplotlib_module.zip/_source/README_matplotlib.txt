

Data visualization examples (add this section to README.txt; add "vizq" to the Modules list)
- Build with:  python build.py vizq   -> writes out/matplotlib.html
- Every Output box is real: each example ran in a fresh Python 3.13 process with Matplotlib 3.11.2, Seaborn 0.13.2,
  pandas 3.0.5, NumPy 2.5.3 (plus SciPy / scikit-learn where used), via vizq/runner.py. The runner saves every open
  figure after the script ends (and any .gif the example writes) and embeds the real images in the page.
  Text output and images are cached in _vizcache/ (one JSON per example), so the build needs no Matplotlib at all.
- To re-run edited examples set VIZ_PY to a Python that has Matplotlib, Seaborn, pandas, NumPy, SciPy and scikit-learn.
- Sample data: vizq/data.py (600-student dataset, seed 2026, and a daily attendance table for one term, seed 7).
- Images are stored as optimised PNGs (256-colour where that is lossless to the eye, full colour for gradients), so the page is about 3 MB.
