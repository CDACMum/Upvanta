
Cassandra examples
- Every CQL example with an Output box is executed at build time by cassandra/cqlsim.py, a deterministic CQL engine
  written for this site that follows Apache Cassandra 5.0's rules: Murmur3Partitioner tokens (bit-identical to
  Cassandra), token order across partitions, clustering order, WHERE-clause restrictions and their exact error
  messages (ALLOW FILTERING, clustering prefix, ORDER BY, GROUP BY), secondary indexes and SAI, upserts with
  last-write-wins timestamps, TTL on a simulated clock (`!sleep N` in an example), tombstones, static columns,
  collections, frozen UDTs, counters, lightweight transactions, batches, materialized views and JSON.
- Output is printed in cqlsh format. Pure Python: `python build.py cassandra` needs no Cassandra and no extra packages.
- Multi-node behaviour (replication, consistency levels, repair) and nodetool commands are shown without output.
