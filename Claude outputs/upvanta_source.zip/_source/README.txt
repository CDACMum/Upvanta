Upvanta module page generator
-----------------------------
Each module's questions live in <module>/sNN_*.py (one file per sidebar section).
Build a page:   python build.py rdbms     -> writes out/rdbms.html
Copy the generated file next to index.html.

build.py  - page template, shared JS (navigation, search, progress) and content helpers
base.css  - styles shared with apache-pyspark.html
