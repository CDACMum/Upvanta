

scikit-learn examples (add this section to README.txt; add "mlq" to the Modules list)
- Build with:  python build.py mlq   -> writes out/sklearn.html
- Every Output box is real: each example ran in a fresh Python 3.13 process with scikit-learn 1.9.1, NumPy 2.5.3,
  pandas 3.0.5 and SciPy 1.18.1, via mlq/runner.py. Outputs are cached in _mlcache/ (one JSON per example).
- While an example is unchanged, the build uses the cache and needs no scikit-learn at all.
- To re-run edited examples set ML_PY to a Python that has scikit-learn, pandas, NumPy and SciPy installed.
- Sample data: mlq/data.py builds a reproducible 600-student dataset (seed 2026) with features attendance, study_hours,
  mock_test, course, centre, degree and targets final_score / placed. Q6 (feature scaling with KNN) and Q33 (PCA) use the built-in
  wine dataset; Q32 uses make_moons; Q35 uses 120 synthetic feedback comments; Q37 adds a synthetic dropout target.
- Animation numbers that say "real run" match the cached outputs; the others are illustrative.
