

Statistics examples (add this section to README.txt; add "statq" to the Modules list)
- Build with:  python build.py statq   -> writes out/statistics.html
- Every Output box is real: each example ran in a fresh Python 3.13 process with NumPy 2.5.3, pandas 3.0.5,
  SciPy 1.18.1 and statsmodels 0.15.0, via statq/runner.py. Outputs are cached in _statcache/ (one JSON per example).
- While an example is unchanged, the build uses the cache and needs no SciPy/statsmodels at all.
- To re-run edited examples set STAT_PY to a Python that has NumPy, pandas, SciPy and statsmodels installed.
- Sample data: statq/data.py builds a reproducible 600-student dataset (seed 2026): centre, course, teaching method
  (traditional/flipped), attendance, study hours, pre/post-test, final score, placed and package (LPA).
  Some examples simulate their own data (A/B test, evaluators, control chart, Simpson's paradox table); this is stated on the page.
- Animation numbers marked "real run" match the cached outputs; scatter clouds and illustrative curves are drawn for explanation.
