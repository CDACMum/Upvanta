Upvanta module page generator
-----------------------------
Each module's questions live in <module>/sNN_*.py (one file per sidebar section).
Build a page:   python build.py rdbms     -> writes out/rdbms.html
Copy the generated file next to index.html.

build.py  - page template, shared JS (navigation, search, progress) and content helpers
base.css  - styles shared with apache-pyspark.html

Modules: rdbms, python, etl, mysql, airflow

SQL examples (rdbms, etl, mysql) run on a MySQL server reachable as `mysql -uroot`.

Airflow examples
- Every DAG in the airflow module was really run with `airflow dags test` on Airflow 3.3.2.
- The runs are cached in _afcache/ (one JSON file per example). While the example code is
  unchanged, `python build.py airflow` uses the cache and needs no Airflow install.
- If you edit an example, the build re-runs it. That needs:
    AF_BIN  = bin folder of a virtualenv with apache-airflow==3.3.2,
              apache-airflow-providers-sqlite and pytest installed
    AF_HOME = an AIRFLOW_HOME where `airflow db migrate` has been run
  (defaults: /home/claude/af/bin and /home/claude/afhome; set the environment variables
  to your own paths).
