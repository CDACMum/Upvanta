
Git & GitHub examples (add this section to README.txt; add "gitq" to the Modules list)
- Build with:  python build.py gitq   -> writes out/git.html
- Every Terminal box is real: each example ran with git 2.43 and bash on Ubuntu 24.04 as the user 'student', in a fresh
  /home/student (work folder ~/cdac) with a fixed ~/.gitconfig (Asha Patil, default branch main), via gitq/runner.py.
- Simulated clock: every git command runs one minute after the previous one, starting 14 Oct 2026 09:00 IST, so commit
  hashes are reproducible and the hashes drawn in the animations match the transcripts.
- Output is cached in _gitcache/ (one JSON per example), so the build needs no Git at all.
- To re-run an edited example, build as root on Linux with git installed and a user called 'student'; the CI example
  (Q32) also needs pytest, and the notebook example (Q35) needs python3. The SSH-key example prints part of a random key,
  so only that line changes when it is re-run.
- Lines starting with '!' in an example are hidden setup commands (run, not shown).
